# Sunny-Frog-Games


<img src="https://dodo.ac/np/images/4/48/Sunny_DnMe%2B.png?version=20edd8cf6bb2ad69a2f93ced6403df18" width="5%"></img>


Click <a href="https://github.com/Sunny-Frog-Games/Sorcer-Striker">HERE</a> to see the GitHub page of the project.

Webpage: https://sunny-frog-games.github.io/Sorcer-Striker/


***
### Team members and its GitHubs <br/>
<a href="https://github.com/HugoUPC">Hugo Planell Moreno</a><br>
<a href="https://github.com/MariaSora">Maria Perarnau Sangüesa</a><br>
<a href="https://github.com/CaseChips">Núria Case Masana</a><br>
<a href="https://github.com/Cifu2004">Albert Cifuentes Burés</a><br>
<a href="https://github.com/PauHeer">Pau Hernández Velázquez</a><br>

***
### Game Description <br/>

Sorcer striker it's a shooter game that is based on a story where players assume the role of one of the four heroes / characters and they’ll have to destroy and kill enemies to finally win the game. The game has different stages where you face numerous enemies shooting them with your spaceship and once you defeat them you have to kill the boss.

***
### Game Controls <br/>

JoyStick Controls:<br>
Left Joystick - Movement<br>
A - Shoot/Confirm action<br>
B - Shoot Bomb<br>

Keyboard Controls:<br>
W - Move Forward<br>
A - Move to the Left<br>
S - Move Backwards<br>
D - Move to the Right<br>
Space - Shoot/Confirm action<br>
B - Shoot Bomb<br>
F1 - DEBUG UI<br>

When Debug UI is opened:<br>
- F1 - God Mode<br>
- F2 - Display Colliders<br>
- F3 - Direct Win<br>
- F4 - Direct Lose<br>
- F5 - Direct to Boss<br>
- F6 - Spawn Objects<br>
- - 1-7 to select the objects<br>
- F8 - Game Speed Multiplier<br>

***
### Additional information <br/>

Enjoy the game :)
    
